<div>
    <p>Name: <span>$name</span>
    <p>Reference: <span>$reference</span>
    <p>price: <span>$reference</span>
    <!--Admin Created to add to invoice-->
    <p>to<p>
    <p>Account Name: <span>$bank Name</span>
    <p>Branch Code: <span>$branch_code</span>
    <p>Account Type: <span>$Account Type</span>
</div>