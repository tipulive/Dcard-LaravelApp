<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->


    <title><?php echo e(config('app.name', 'Stock')); ?></title>
    <link rel="stylesheet" href="fonts/icomoon/style.css">



    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Style -->
    <link rel="stylesheet" href="css/style.css">

  <style>



	</style>

</head>
<body>
<div class="cover-spin"></div>

        <?php echo $__env->yieldContent('content'); ?>


    <!-- Scripts -->

</body>
</html>
<?php /**PATH E:\amyapp\aaClientCard\DcardLaravel\Dcard\resources\views/layouts/app.blade.php ENDPATH**/ ?>