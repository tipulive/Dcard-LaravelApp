<div class="au-card visible_div">
<h3 class="title-2 m-b-10 text-center docname"></h3>
<input type="hidden" class="tableid">
<hr>
<div class="table-responsive  m-b-40">
    <br>
   
                    <table id="Table_reportusers"  class="table table-borderless table-data3" cellspacing="0" width="100%">
                         <thead>

                         @include('components.Table.components.table_reportusers_client')
                         @include('components.Table.components.table_reportusers_pharmacy')
                         @include('components.Table.components.table_reportusers_Super')

                      </thead>
                        
                        
                    </table>
                </div>
                <hr>
                </div>