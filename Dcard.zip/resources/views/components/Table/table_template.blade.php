<div class="table-responsive">
    <br>
   
                    <table id="table_template"  class="table table-striped" cellspacing="0" width="100%">
                         <thead>
<tr>
    <th>Id</th>
    <th>First Name</th>
    
    <th>Surname</th>
    <th>Action</th>


   
   
  
    
</tr>
</thead>
                        
                        
                    </table>
                </div>
