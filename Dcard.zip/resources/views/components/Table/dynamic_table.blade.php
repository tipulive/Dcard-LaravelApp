<table id="demotable" class="table table-striped table-condensed dataTable">
        <thead><tr></tr></thead>
    </table>