<tr class="Super d-none">
    <th>ID</th>
    <th>Client Id</th>
    <th>Reported ID</th>
    
    <th>Status</th>
    
    <th>Created_at</th>
    <th>Updated_at</th>
    <th>Action</th>


   
   
  
    
</tr> 