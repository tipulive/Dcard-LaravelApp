<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Auth;

class ParticipateController extends Controller
{
    //

    public function __construct()
    {
        date_default_timezone_set(env('TIME_ZONE'));
        $this->today = date('Y-m-d H:i:s', time());
        $this->Appstate=env('APP_LIVE')?env('APP_PRO'):env('APP_DEV');
        $this->AppName=env('APP_NAME');

        $this->otp='1 hours';
      // $this->otp='20 seconds';//test purpose
        $this->email_confirm='24 hours';
        $this->Admin_Auth_error="You Are not authenticate please Request Permission to Admin";
        $this->Admin_Auth_result_error="0";//Admin auth result zero

    }

    public function ParticipateEvent($input)
    {

        $check=DB::select("select uid,uidUser,subscriber from participateds where uid=:uid and uidUser=:uidUser and subscriber=:subscriber  limit 1",array(
            "uid"=>$input['uid'],//event Id
            "uidUser"=>$input['uidUser'],
           // "subscriber"=>$input['subscriber']
            "subscriber"=>Auth::user()->subscriber
        ));

        if($check)
        {

                 $inputData=$input["inputData"];
            $check1=DB::update("update participateds set inputData=inputData+$inputData where uid=:uid and uidUser=:uidUser and subscriber=:subscriber limit 1",array(
                "uid"=>$input['uid'],
                "uidUser"=>$input['uidUser'],
                "subscriber"=>Auth::user()->subscriber
            ));

            if($check1)
            {

             return response([
                 "status"=>true,
                 "result"=>$check1


             ],200);
            }
            else{
             return response([
                 "status"=>false,
                 "result"=>$check1,

             ],200);
            }


        }
        else{

            $check2=DB::table("participateds")
            ->insert([
            "uid"=>$input["uid"],
            "uidUser"=>$input['uidUser'],
            "subscriber"=>Auth::user()->subscriber,
            "inputData"=>$input["inputData"],
            "uidCreator"=>Auth::user()->uid,
            "created_at"=>$this->today
            ]);

        if($check2)
        {

         return response([
             "status"=>true,
             "result"=>$check2


         ],200);
        }
        else{
         return response([
             "status"=>false,
             "result"=>$check2,

         ],200);
        }

        }
    }

    public function ParticipateEditEvent($input)//not finished
    {



                 $inputData=$input["inputData"];
            $check=DB::update("update participateds set inputData=inputData+$inputData where uid=:uid and uidUser=:uidUser limit 1",array(
                "uid"=>$input['uid'],
                "uidUser"=>Auth::user()->uidUser
            ));

            if($check1)
            {

             return response([
                 "status"=>true,
                 "result"=>$check1


             ],200);
            }
            else{
             return response([
                 "status"=>false,
                 "result"=>$check1,

             ],200);
            }



    }

    public function GetAllParticipateEvent($input)//not finished
    {




            $check=DB::select("select *from participateds where uidUser=:uidUser and subscriber=:subscriber limit 100",array(
                 "uidUser"=>$input["uidUser"],
                "subscriber"=>Auth::user()->subscriber
            ));

            if($check)
            {

             return response([
                 "status"=>true,
                 "result"=>$check


             ],200);
            }
            else{
             return response([
                 "status"=>false,
                 "result"=>$check,

             ],200);
            }



    }
}
